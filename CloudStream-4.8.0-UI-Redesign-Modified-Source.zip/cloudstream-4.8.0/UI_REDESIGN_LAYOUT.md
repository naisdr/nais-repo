# CloudStream 4.8.0 — reference-style detail UI revision

This revision reshapes the phone detail page toward the supplied reference:

1. The actual poster image is used as the hero image; trailer playback is not shown over it by default.
2. The title is overlaid on the lower part of the poster.
3. Compact metadata shows year, episode count, and genre tags.
4. A large white `PUTAR • E1` button appears over the hero and delegates to the existing resume/play action or first episode row.
5. Search, My List, and Favorite actions are placed beneath the play button.
6. The description follows the hero.
7. Episode, Recommendations, and Trailer tabs follow the description.
8. The existing episode controls/list remain below the tabs.

The old inline play/download action row is hidden to avoid duplicate controls. The cast carousel and provider/type metadata are hidden to keep the requested order. Existing player, bookmark, favorite, search, and recommendations actions are reused.

Validation performed: `fragment_result.xml` parses successfully and has no duplicate IDs. This source revision has **not** been built or device-tested in this environment; run GitHub Actions and test the generated debug APK before relying on it.
