# CloudStream Original 4.8.0 — UI redesign build notes

This source tree contains a limited first-pass UI patch targeting only the detail screen and episode row.

## UI changes
- Detail title size increased slightly for a more prominent series heading.
- Detail description uses the theme's secondary gray text color.
- Main Play button uses a capsule-style 28dp corner radius.
- Episode cards are flatter, use a black background, remove card elevation, increase vertical spacing, and use a slightly larger thumbnail.
- Episode download/action wiring and the original Kotlin adapter are unchanged.

## Build APK on GitHub Actions
1. Create a repository from this source tree (or upload it to a new GitHub repository).
2. Open **Actions** and enable workflows if prompted.
3. Select **Build CloudStream UI redesign APK**.
4. Press **Run workflow**.
5. When the run completes, download the `CloudStream-Original-4.8.0-UI-Redesign` artifact.

The workflow builds the stable release variant, signs it with a temporary generated key, verifies the signature, and records the SHA-256 checksum. Since the key is generated for that workflow run, future builds will have a different signing identity. The APK will not install as an update over an existing official CloudStream install signed with a different certificate; uninstalling the existing app may be required, which can remove app-local data. Back up data first.

## Validation limits
This environment did not complete a local Gradle build because it could not resolve `services.gradle.org`. The APK must be built in the workflow and runtime-tested on a device before claiming it is bug-free. The current patch is a first-pass visual adaptation, not a pixel-perfect verified copy of CloudStreamXR Beta.
