# Subtitle Auto-Language Persistence Fix

## Problem
The automatic subtitle language selected in Subtitle Settings was being overwritten by playback track changes/callbacks. This could leave the setting displaying `null` or an empty value after starting a video.

## Change
- Updated `app/src/main/java/com/lagradost/cloudstream3/ui/player/GeneratorPlayer.kt`.
- Removed the write from the player track-selection method to the global `SUBTITLE_AUTO_SELECT_KEY`.
- Playback track changes now remain local to the current player session.
- The global automatic subtitle language is changed only through Subtitle Settings, which owns that preference.

## Compatibility / scope
- No UI layout, player engine, subtitle matching, download, or CloudStream core code was changed.
- No Gradle or Android SDK configuration was changed.
- The existing setting key and default language behavior remain unchanged.

## Validation
- Source ZIP extracted successfully.
- Confirmed the player track-selection method no longer writes the global automatic subtitle-language key.
- Gradle compilation and device playback testing have **not** been run; runtime behavior remains unverified until built and tested.
