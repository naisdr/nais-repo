# Subtitle settings compile fix

## Based on
`CloudStream-4.9.0-UI-Redesign.zip` uploaded in this conversation.

## Change
- Updated `app/src/main/java/com/lagradost/cloudstream3/ui/subtitles/SubtitlesScreen.kt`.
- Declared the download-language `MultiSelectListPreference` generic type explicitly as `String`.
- Removed a custom `subtitleProvider` that treated the multi-select value (`Set<String>`) as a single `String` and called `isNotBlank()` on it. The shared preference component's built-in provider already formats a set of selected values and handles an empty set.

## Scope
No player selection logic, language preference key, UI layout, toolbar, or other application behavior was changed in this compile-only correction.

## Validation
- ZIP integrity checked after packaging.
- Kotlin/Gradle compilation not run in this environment; GitHub Actions must verify compilation.
