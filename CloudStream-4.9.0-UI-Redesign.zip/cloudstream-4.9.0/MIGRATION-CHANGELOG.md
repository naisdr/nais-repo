# CloudStream 4.9.0 UI Redesign Migration Changelog

## Basis
- Base project: CloudStream Original 4.9.0 (`cloudstream-4.9.0.zip`).
- UI/behavior reference: CloudStream 4.8.0 `Stable fix2.zip`.
- Migration approach: selective transplant; the 4.9.0 project structure, Gradle configuration, core modules, serialization model, and ViewModel implementation remain the source of truth.

## Files modified
1. `app/src/main/java/com/lagradost/cloudstream3/ui/result/ResultFragmentPhone.kt`
   - Selectively applied the detail-page UI and behavior changes from Stable fix2 onto the 4.9.0 implementation.
   - Added inline recommendation state and tab handling.
   - Added the unified Play/Continue button behavior and history progress binding.
   - Added watchlist/favorite action-row presentation while reusing CloudStream's existing actions and history/download handling.
   - Kept the static poster behavior and the reduced detail toolbar action visibility.
   - Kept the 4.9.0 source as the patch base; no wholesale Kotlin file replacement.
2. `app/src/main/res/layout/fragment_result.xml`
   - Migrated the redesigned detail content layout from Stable fix2.
   - Preserved all 4.9.0 resource IDs required by the current phone fragment binding; the redesigned layout adds the Netflix-style action row, detail tabs, inline recommendations, title overlay, and history progress view.
3. `app/src/main/res/drawable/result_play_parent_clip.xml`
   - Added the rounded clipping drawable used by the primary playback button container.

## Intentionally retained from 4.9.0
- `ResultFragment.kt`, including `@Serializable` / `@SerialName` annotations on `ResultEpisode`.
- `ResultViewModel2.kt`, including the 4.9.0 cast episode-index handling.
- `ResultFragmentTv.kt`, `fragment_result_tv.xml`, and `fragment_result_swipe.xml`.
- Gradle wrapper, plugin versions, dependency declarations, SDK levels, JVM target, and all modules including `shared` and `desktopApp`.
- Other 4.9.0 features and resources not required by the migrated detail UI.

## Compatibility notes / risks to verify
- The phone detail fragment uses the existing 4.9.0 `FragmentResultSwipeBinding` and its fixed top-bar container; the detail content remains inside the existing included `fragment_result` layout.
- The custom Kotlin behavior relies on the existing 4.9.0 ViewModel and history observers. Runtime behavior for movie/series resume, seasonless series, and returning from the player still requires device testing.
- The poster recommendation aspect ratio and recycled-view behavior require runtime verification after opening a movie, playing it, returning to detail, and scrolling recommendations.
- The red history progress line is wired to saved progress values, but its exact visual clipping/shape and visibility require runtime verification.
- The requested watchlist labels are still literal UI strings in the migrated behavior; localization consistency should be reviewed separately if required.

## Validation performed
- Both input ZIP archives passed ZIP integrity checks before migration.
- All XML files in the resulting project's `app/src/main/res` tree parsed successfully with an XML parser (0 parse errors).
- The migrated layout contains the custom view IDs referenced by the migrated phone fragment.
- Resource reference scan found no missing project drawable used by the migrated Kotlin code. One platform/dependency drawable reference (`cast_ic_mini_controller_skip_next`) is not a project-local resource and is supplied by the existing dependency/resource setup.
- Gradle compilation was attempted with `./gradlew :app:compileDebugKotlin --no-daemon`, but could not start because the environment could not resolve `services.gradle.org` to download the Gradle 9.4.1 distribution (`UnknownHostException`).

## Not yet verified
- Kotlin compilation and Android resource linking.
- APK build, installation, and runtime UI behavior on phone/Android TV.
- Actual sticky toolbar behavior during scroll, playback resume state transitions, download flows, cast, and player return behavior.
- Final visual validation of recommendation poster proportions and progress-bar clipping.

**Build status: NOT VERIFIED. No APK was produced.**


## Subtitle auto-language preference fix (2026-11-09)

- `GeneratorPlayer.kt`: selecting playback-only "No subtitles" no longer writes an empty string over the saved automatic subtitle-language preference. Selecting a real subtitle track still saves its language.
- `SubtitlesScreen.kt`: empty and legacy `None` preference values are displayed as the localized "None" label instead of `null`.
- Validation: source-level patch and XML-independent Kotlin text checks only. Gradle compilation and device playback have not yet been run.
