# Subtitle Auto-Language Persistence Fix

Base source: Stable 4.9.0 fix2.zip
Reference source: Stable fix2.zip (CloudStream 4.8.0)

## Findings
- The 4.8.0 and 4.9.0 `GeneratorPlayer` implementations use the same basic auto-select preference key and the same player-side persistence flow.
- CloudStream 4.9.0 introduces the Compose `SubtitlesScreen` and `DataPreferenceStore` list preference UI.
- The 4.9.0 language list displays a value by looking it up in the language-entry map. A stored legacy/alias code not present as a canonical IETF key can therefore render as `null`.
- Subtitle matching previously compared tags strictly, and metadata code aliases such as legacy ISO codes could fail to resolve to the canonical IETF tag.

## Changes
1. Added `SubtitleHelper.fromLanguageCodeToTagIETF()` to canonicalize IETF, ISO 639-1/2/3, and OpenSubtitles language codes.
2. Updated `SubtitleData.getIETF_tag()` and `matchesLanguageCode()` to normalize aliases before comparison. This is intended to make Indonesian aliases resolve to canonical `id`.
3. Updated the player settings getter to normalize a saved legacy code before the player uses it.
4. Added legacy language-code aliases to the Compose language-entry map so older stored values still display the correct language instead of `null`.
5. Added a safe display fallback for empty/unknown values so the settings UI does not render the literal `null`.
6. Player-side 'No subtitles' selection no longer clears the app-level auto-language preference; only a valid manually selected subtitle track can update the saved language.
7. Prevented automatic downloaded-subtitle fallback from overriding an explicit empty/None subtitle preference.

## Files modified
- `library/src/commonMain/kotlin/com/lagradost/cloudstream3/utils/SubtitleHelper.kt`
- `app/src/main/java/com/lagradost/cloudstream3/ui/player/PlayerSubtitleHelper.kt`
- `app/src/main/java/com/lagradost/cloudstream3/ui/player/GeneratorPlayer.kt`
- `app/src/main/java/com/lagradost/cloudstream3/ui/subtitles/SubtitlesFragment.kt`
- `app/src/main/java/com/lagradost/cloudstream3/ui/subtitles/SubtitlesScreen.kt`

## Validation
- ZIP extraction: passed.
- Kotlin source brace-balance sanity check: passed.
- Full Gradle compilation: not run in this environment.
- Device playback verification: not run.
